#include <stdio.h>
main()
{
 printf("*\n**\n***\n**\n*\n");
}

