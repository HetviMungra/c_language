#include <stdio.h>
main()
{
    printf("Hetvi\n");
    printf("17\n");
    printf("R&W\n");
}