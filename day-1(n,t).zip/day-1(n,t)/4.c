#include <stdio.h>

 main(){
    printf("*\n*\n*\n");
    printf("*         * *               *\n");
    printf("*        *    *           *\n");
    printf("*      *        *      *\n");
    printf("*    *            * *\n");
    printf("*  *\n");
    printf("*");
}